package com.detica.handler;

import java.util.Date;

import junit.framework.Assert;

import org.junit.Test;

import com.detica.handler.dto.CallDTO;
import com.detica.handler.dto.ResponseDTO;
import com.detica.handler.payload.ResponsePayload;

public class ResponseHandlerTestCase {

	@Test
	public void test() {
		ResponseHandler testInstance = new ResponseHandler();
		ResponsePayload payload;
		ResponseDTO responseDto;
		payload = new ResponsePayload();
		responseDto = new ResponseDTO();
		CallDTO callDTO = new CallDTO();
		callDTO.setDuration(10);
		callDTO.setOriginatingNumber("0750075099");
		callDTO.setTerminatingNumber("0752275099");
		callDTO.setTimestamp(new Date());
		responseDto.addResult(callDTO);
		testInstance.populateProductResponse(payload, responseDto);
		Assert.assertEquals(1, payload.getCount());
	}

}
