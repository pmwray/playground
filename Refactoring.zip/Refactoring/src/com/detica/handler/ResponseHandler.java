package com.detica.handler;

import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.List;

import com.detica.handler.dto.CallDTO;
import com.detica.handler.dto.ResponseDTO;
import com.detica.handler.dto.SubscriberDTO;
import com.detica.handler.dto.TextDTO;
import com.detica.handler.payload.AddressElement;
import com.detica.handler.payload.CallElement;
import com.detica.handler.payload.NameElement;
import com.detica.handler.payload.Payload;
import com.detica.handler.payload.ResponsePayload;
import com.detica.handler.payload.SubscriberElement;
import com.detica.handler.payload.TelephoneNumberElement;
import com.detica.handler.payload.TextElement;
import com.detica.handler.payload.TimeRangeElement;

public class ResponseHandler {
	
	private ResponsePayload payload;
	private ResponseDTO responseDto;

	public void populateProductResponse(ResponsePayload payload,
			ResponseDTO responseDto) {
		this.payload = payload;
		this.responseDto = responseDto;
		
		if (responseDto.getResults().get(0) instanceof CallDTO) {
			this.populateCallResponse();
		}
		if (responseDto.getResults().get(0) instanceof SubscriberDTO) {
			this.populateSubscriberResponse();
		}
		if (responseDto.getResults().get(0) instanceof TextDTO) {
			this.populateTextResponse();
		}
	
}
	private void populateTextResponse() {
		List<Object> results = responseDto.getResults();
		for (Object object : results) {
			TextDTO text = (TextDTO) object;
			Payload p = new Payload();
			TextElement textElement = new TextElement();
			p.setTextElement(textElement);
			textElement.setOriginating(new TelephoneNumberElement());
			textElement.getOriginating().setNumber(text.getOriginatingNumber());
			textElement.setTerminating(new TelephoneNumberElement());
			textElement.getTerminating().setNumber(text.getTerminatingNumber());
			textElement.setText(text.getData());
			TimeRangeElement range = new TimeRangeElement();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			range.setStart(sdf.format(text.getTimestamp()));
			textElement.setTime(range);
			payload.addPayload(p);
			payload.setCount(payload.getCount()+ 1);
		}
	}

	private void populateSubscriberResponse() {
		List<Object> results = responseDto.getResults();
		for (Object object : results) {
			SubscriberDTO subscriber = (SubscriberDTO) object;
			Payload p = new Payload();
			SubscriberElement subscriberElement = new SubscriberElement();
			p.setSubscriberElement(subscriberElement);
			NameElement name = new NameElement();
			subscriberElement.setName(name);
			name.setFirstName(subscriber.getFirstName());
			name.setLastName(subscriber.getLastName());
			AddressElement address = new AddressElement();
			address.setPostCode(subscriber.getPostCode());
			subscriberElement.setAddress(address);
			payload.addPayload(p);
			payload.setCount(payload.getCount()+ 1);
		}

	}

	private void populateCallResponse() {
		List<Object> results = responseDto.getResults();
		for (Object object : results) {
			CallDTO call = (CallDTO) object;
			Payload p = new Payload();
			CallElement callElement = new CallElement();
			p.setCallElement(callElement);
			callElement.setOriginating(new TelephoneNumberElement());
			callElement.getOriginating().setNumber(call.getOriginatingNumber());
			callElement.setTerminating(new TelephoneNumberElement());
			callElement.getTerminating().setNumber(call.getTerminatingNumber());
			TimeRangeElement range = new TimeRangeElement();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			range.setStart(sdf.format(call.getTimestamp()));
			GregorianCalendar calendar = new GregorianCalendar();
			calendar.setTime(call.getTimestamp());
			calendar.add(GregorianCalendar.SECOND, call.getDuration());
			range.setEnd(sdf.format(calendar.getTime()));
			callElement.setTime(range);
			payload.addPayload(p);
			payload.setCount(payload.getCount()+ 1);
		}
	}

}
