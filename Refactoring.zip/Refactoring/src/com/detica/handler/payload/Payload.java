package com.detica.handler.payload;

public class Payload {

private CallElement callElement;
	
	private TextElement textElement;
	
	private SubscriberElement subscriberElement;

	public CallElement getCallElement() {
		return callElement;
	}

	public void setCallElement(CallElement callElement) {
		this.callElement = callElement;
	}

	public TextElement getTextElement() {
		return textElement;
	}

	public void setTextElement(TextElement textElement) {
		this.textElement = textElement;
	}

	public SubscriberElement getSubscriberElement() {
		return subscriberElement;
	}

	public void setSubscriberElement(SubscriberElement subscriberElement) {
		this.subscriberElement = subscriberElement;
	}
}
