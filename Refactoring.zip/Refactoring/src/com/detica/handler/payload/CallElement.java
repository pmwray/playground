package com.detica.handler.payload;

public class CallElement {

	private TelephoneNumberElement originating;
	
	private TelephoneNumberElement terminating;
	
	private TimeRangeElement time;

	public TelephoneNumberElement getOriginating() {
		return originating;
	}

	public void setOriginating(TelephoneNumberElement originating) {
		this.originating = originating;
	}

	public TelephoneNumberElement getTerminating() {
		return terminating;
	}

	public void setTerminating(TelephoneNumberElement terminating) {
		this.terminating = terminating;
	}

	public TimeRangeElement getTime() {
		return time;
	}

	public void setTime(TimeRangeElement timeRangeElement) {
		this.time = timeRangeElement;
	}
	
	
}
