package com.detica.handler.payload;

public class SubscriberElement {

	private NameElement name;
	
	private AddressElement address;

	public NameElement getName() {
		return name;
	}

	public void setName(NameElement name) {
		this.name = name;
	}

	public AddressElement getAddress() {
		return address;
	}

	public void setAddress(AddressElement address) {
		this.address = address;
	}
}
