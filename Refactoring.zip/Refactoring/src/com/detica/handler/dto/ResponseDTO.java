package com.detica.handler.dto;

import java.util.ArrayList;
import java.util.List;

public class ResponseDTO {

	private List<Object> results = new ArrayList<Object>();
	
	public List<Object> getResults() {
		return this.results;
	}
	
	public void addResult(Object object) {
		this.results.add(object);
	}
}
