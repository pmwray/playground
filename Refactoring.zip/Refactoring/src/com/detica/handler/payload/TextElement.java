package com.detica.handler.payload;

public class TextElement {

	private String text;
	
	private TimeRangeElement time;
	
	private TelephoneNumberElement originating;
	
	private TelephoneNumberElement terminating;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public TimeRangeElement getTime() {
		return time;
	}

	public void setTime(TimeRangeElement timeElement) {
		this.time = timeElement;
	}

	public TelephoneNumberElement getOriginating() {
		return originating;
	}

	public void setOriginating(TelephoneNumberElement originating) {
		this.originating = originating;
	}

	public TelephoneNumberElement getTerminating() {
		return terminating;
	}

	public void setTerminating(TelephoneNumberElement terminating) {
		this.terminating = terminating;
	}
}
