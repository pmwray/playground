package com.detica.handler.dto;

import java.util.Date;

public class TextDTO {

	private String data;
	
	private String originatingNumber;
	
	private String terminatingNumber;
	
	private Date timestamp;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getOriginatingNumber() {
		return originatingNumber;
	}

	public void setOriginatingNumber(String originatingNumber) {
		this.originatingNumber = originatingNumber;
	}

	public String getTerminatingNumber() {
		return terminatingNumber;
	}

	public void setTerminatingNumber(String terminatingNumber) {
		this.terminatingNumber = terminatingNumber;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
}
